﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SergioHalimTakeHomeAssignmentWeek5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(!File.Exists(Directory.GetCurrentDirectory() + "/Wordle Word List.txt"))
            {
                MessageBox.Show("Data Wordle tidak ditemukan.");
            }

            else
            {
                bool check = false;
                try
                {
                    int number = int.Parse(textBox1.Text);

                    if (number >= 3)
                    {
                        check = true;
                    }

                    else
                    {
                        MessageBox.Show("Number must be 3 or more.");
                    }

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Input should be number");
                }

                if (check)
                {
                    Form2 game = new Form2(int.Parse(textBox1.Text));
                    game.ShowDialog();
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
