﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace SergioHalimTakeHomeAssignmentWeek5
{
    public partial class Form2 : Form
    {
        public MyTextBox[,] textBoxData;
        public string[] wordleData;
        public char[] wordSplit;

        public int total;
        public int occurence = 0;
        public string randomKata;

        public Form2(int total)
        {
            InitializeComponent();

            this.total = total;

            textBoxData = new MyTextBox[total, 5];
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string content = File.ReadAllText(Directory.GetCurrentDirectory() + "/Wordle Word List.txt");

            wordleData = content.Split(',');

            Random random = new Random();

            randomKata = wordleData[random.Next(wordleData.Length)];
            wordSplit = randomKata.ToCharArray();

            int y = 100;
            for (int i = 0; i < total; i++)
            {
                int x = 100;
                for (int j = 0; j < 5; j++)
                {
                    textBoxData[i, j] = new MyTextBox("textBox-" + i + "-" + j, 50, 50, x, y);
                    this.Controls.Add(textBoxData[i, j]);
                    x += 55;
                }
                y += 55;
            }
        }

        public class MyTextBox : TextBox
        {
            public MyTextBox(String name, int sizex, int sizey, int posx, int posy)
            {
                this.Text = "";
                this.Multiline = true;
                this.Location = new Point(posx, posy);
                this.Width = sizex;
                this.Height = sizey;
                this.Name = name;
                this.TabStop = false;
                this.TextAlign = HorizontalAlignment.Center;
                this.Font = new Font(Font.FontFamily, 30);
                this.ReadOnly = true;
                this.BackColor = Color.Cyan;
            }
        }

        public void clickButton(object sender, EventArgs e)
        {
            var buttons = sender as Button;
            String isi = buttons.Text;

            if(isi == "Enter")
            {
                int trapMatch = 0;
                string textCheck = textBoxData[occurence, 0].Text + textBoxData[occurence, 1].Text + textBoxData[occurence, 2].Text + textBoxData[occurence, 3].Text + textBoxData[occurence, 4].Text;

                if(Array.IndexOf(wordleData, textCheck.ToLower()) != -1)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (textBoxData[occurence, j].Text.ToLower() == wordSplit[j].ToString())
                        {
                            textBoxData[occurence, j].BackColor = Color.LightGreen;
                            trapMatch++;
                        }
                        else
                        {
                            for (int k = 0; k < 5; k++)
                            {
                                if (textBoxData[occurence, j].Text.ToLower() == wordSplit[j].ToString())
                                {
                                    textBoxData[occurence, j].BackColor = Color.LightYellow;
                                }
                            }
                        }
                    }

                    if(trapMatch == 5)
                    {
                        MessageBox.Show("Berhasil");
                    }

                    occurence = occurence + 1;
                }
                else
                {
                    MessageBox.Show(textCheck + " is not on the Word List");
                }
            }
            else if(isi == "Delete")
            {
                bool challenge = true;

                for (int j = 0; j < 5; j++)
                {
                    if (textBoxData[occurence, j].Text == "")
                    {
                        if(j > 0)
                        {
                            textBoxData[occurence, j - 1].Text = "";
                            challenge = false;
                        }
                    }
                }
                if (challenge)
                {
                    textBoxData[occurence, 4].Text = "";
                }
            }
            else
            {
                if (occurence < total)
                {
                    for (int j = 0; j < 5; j++)
                    {
                        if (textBoxData[occurence, j].Text == "")
                        {
                            textBoxData[occurence, j].Text = isi; 
                            break;
                        }
                    }
                }
            }
        }
    }
}
